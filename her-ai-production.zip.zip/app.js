// Her AI - Advanced Menstrual Health Tracker
// Production-ready application with encryption, voice commands, and AI insights

class HerAI {
    constructor() {
        this.version = '2.0.0';
        this.currentDate = new Date();
        this.currentLanguage = 'en';
        this.voiceRecognition = null;
        this.voiceSynthesis = window.speechSynthesis;
        this.isListening = false;
        this.isOnboarding = true;
        this.currentStep = 1;
        this.maxSteps = 3;
        this.encryptionKey = null;
        this.offlineMode = !navigator.onLine;
        this.chart = null;
        
        // Initialize data structures
        this.userData = {};
        this.healthData = {};
        this.translations = {};
        
        this.init();
    }

    async init() {
        try {
            // Initialize core systems
            await this.initializeTranslations();
            await this.loadUserData();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Check if user has completed onboarding
            if (this.userData.onboardingComplete) {
                this.completeOnboarding();
            } else {
                this.startOnboarding();
            }
            
            // Initialize voice commands if available
            this.initializeVoiceCommands();
            
        } catch (error) {
            console.error('Initialization error:', error);
            this.showNotification('Initialization failed. Please refresh the page.', 'error');
        }
    }

    // ===========================================
    // INITIALIZATION METHODS
    // ===========================================

    async initializeTranslations() {
        this.translations = {
            en: {
                welcome_back: "Welcome Back!",
                health_score: "Health Score",
                cycle_day: "Cycle Day",
                next_period: "Next Period",
                confidence: "confidence",
                quick_actions: "Quick Actions",
                log_period: "Log Period",
                log_symptoms: "Log Symptoms",
                medications: "Medications",
                track_health: "Track Your Health",
                period_tracking: "Period Tracking",
                period_desc: "Log your period dates and flow intensity",
                symptoms_mood: "Symptoms & Mood",
                symptoms_desc: "Track pain, mood, and physical symptoms",
                med_desc: "Track medications and supplements",
                appointments: "Appointments",
                appointment_desc: "Schedule and track medical appointments",
                recent_entries: "Recent Entries",
                health_insights: "Health Insights",
                predictions: "Predictions",
                cycle_length: "Cycle Length",
                ovulation: "Ovulation",
                fertile_window: "Fertile Window",
                cycle_trends: "Cycle Trends",
                ai_insights: "AI Health Insights",
                pattern_analysis: "Pattern Analysis",
                health_reports: "Health Reports",
                generate_report: "Generate Medical Report",
                comprehensive_report: "Comprehensive Report (6 months)",
                summary_report: "Summary Report (3 months)",
                symptoms_report: "Symptoms Only",
                generate_pdf: "Generate PDF Report",
                export_data: "Export Data",
                share_report: "Share Report",
                summary_stats: "Summary Statistics",
                avg_cycle: "Avg Cycle Length",
                avg_period: "Avg Period Length",
                avg_pain: "Avg Pain Level",
                cycles_tracked: "Cycles Tracked",
                regularity: "Regularity Score",
                total_symptoms: "Total Symptoms",
                settings: "Settings",
                privacy_data: "Privacy & Data",
                notifications: "Notifications",
                accessibility: "Accessibility",
                emergency_contacts: "Emergency Contacts",
                about_her_ai: "About Her AI",
                home: "Home",
                track: "Track",
                insights: "Insights",
                reports: "Reports",
                listening: "Listening...",
                speak_now: "Speak now",
                cancel: "Cancel",
                tap_to_speak: "Tap to speak",
                setup_profile: "Set Up Your Health Profile",
                age: "Age",
                avg_cycle_length: "Average Cycle Length (days)",
                last_period: "Last Period Start Date",
                privacy_settings: "Privacy & Security",
                data_encryption: "Data Encryption",
                encryption_desc: "Your data is encrypted and stored locally on your device only.",
                enabled: "✓ Enabled",
                voice_commands: "Voice Commands",
                voice_desc: "Enable voice commands for hands-free tracking.",
                previous: "Previous",
                next: "Next",
                get_started: "Get Started",
                processing: "Processing your data...",
                save_entry: "Save Entry",
                period_start_date: "Period Start Date",
                period_end_date: "Period End Date (Optional)",
                flow_intensity: "Flow Intensity",
                spotting: "Spotting",
                light: "Light",
                medium: "Medium",
                heavy: "Heavy",
                very_heavy: "Very Heavy",
                additional_notes: "Additional Notes",
                date: "Date",
                time: "Time",
                physical: "Physical",
                emotional: "Emotional",
                lifestyle: "Lifestyle",
                pain_level: "Pain Level (0-10)",
                physical_symptoms: "Physical Symptoms",
                cramps: "Cramps",
                bloating: "Bloating",
                headache: "Headache",
                fatigue: "Fatigue",
                nausea: "Nausea",
                dizziness: "Dizziness",
                backache: "Back Pain",
                breast_tenderness: "Breast Tenderness",
                hot_flashes: "Hot Flashes",
                insomnia: "Insomnia",
                constipation: "Constipation",
                diarrhea: "Diarrhea",
                joint_pain: "Joint Pain",
                muscle_aches: "Muscle Aches",
                acne: "Acne",
                overall_mood: "Overall Mood",
                emotional_symptoms: "Emotional Symptoms",
                mood_swings: "Mood Swings",
                anxiety: "Anxiety",
                depression: "Depression",
                irritability: "Irritability",
                crying_spells: "Crying Spells",
                low_self_esteem: "Low Self-esteem",
                sleep_quality: "Sleep Quality (1-10)",
                energy_level: "Energy Level (1-10)",
                food_cravings: "Food Cravings",
                sweet_cravings: "Sweet Foods",
                salty_cravings: "Salty Foods",
                chocolate_cravings: "Chocolate",
                carb_cravings: "Carbohydrates",
                water_intake: "Water Intake (glasses)",
                exercise_minutes: "Exercise (minutes)",
                close: "Close"
            }
        };
        
        // Load saved language preference
        const savedLang = this.getStorageItem('preferred_language');
        if (savedLang && this.translations[savedLang]) {
            this.currentLanguage = savedLang;
        }
    }

    async loadUserData() {
        try {
            const storedUserData = this.getStorageItem('user_data');
            if (storedUserData) {
                this.userData = storedUserData;
            } else {
                this.userData = {
                    onboardingComplete: false,
                    profile: {},
                    settings: {
                        language: 'en',
                        theme: 'auto',
                        voiceEnabled: true,
                        notifications: {
                            period: 1,
                            medications: true,
                            appointments: true
                        }
                    }
                };
            }

            const storedHealthData = this.getStorageItem('health_data');
            if (storedHealthData) {
                this.healthData = storedHealthData;
            } else {
                this.healthData = {
                    cycles: [
                        {
                            id: 1,
                            startDate: "2025-08-15",
                            endDate: "2025-08-20",
                            cycleLength: 28,
                            flow: ["medium", "heavy", "medium", "light", "light"]
                        },
                        {
                            id: 2,
                            startDate: "2025-09-12",
                            endDate: "2025-09-17",
                            cycleLength: 29,
                            flow: ["light", "medium", "heavy", "medium", "light"]
                        }
                    ],
                    symptoms: [
                        {
                            id: 1,
                            date: "2025-09-10",
                            pain: 6,
                            mood: "irritable",
                            physicalSymptoms: ["cramps", "bloating"],
                            sleep: 6,
                            energy: 4
                        },
                        {
                            id: 2,
                            date: "2025-09-15",
                            pain: 8,
                            mood: "sad",
                            physicalSymptoms: ["headache", "fatigue"],
                            sleep: 5,
                            energy: 3
                        }
                    ],
                    medications: [],
                    appointments: [],
                    insights: [],
                    lastBackup: null
                };
            }
        } catch (error) {
            console.error('Data loading failed:', error);
            this.userData = { onboardingComplete: false, profile: {}, settings: {} };
            this.healthData = { cycles: [], symptoms: [], medications: [], appointments: [] };
        }
    }

    async initializeVoiceCommands() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.voiceRecognition = new SpeechRecognition();
            
            this.voiceRecognition.continuous = false;
            this.voiceRecognition.interimResults = true;
            this.voiceRecognition.lang = this.getLanguageCode(this.currentLanguage);
            
            this.voiceRecognition.onresult = (event) => {
                const result = event.results[event.results.length - 1];
                if (result.isFinal) {
                    this.processVoiceCommand(result[0].transcript);
                } else {
                    const transcriptEl = document.getElementById('voice-transcript');
                    if (transcriptEl) {
                        transcriptEl.textContent = result[0].transcript;
                    }
                }
            };
            
            this.voiceRecognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.stopVoiceRecognition();
                this.showNotification('Voice recognition failed: ' + event.error, 'error');
            };
            
            this.voiceRecognition.onend = () => {
                this.stopVoiceRecognition();
            };
        }
    }

    // ===========================================
    // EVENT LISTENERS
    // ===========================================

    setupEventListeners() {
        // Onboarding navigation - Fixed implementation
        const nextBtn = document.getElementById('next-btn');
        const prevBtn = document.getElementById('prev-btn');
        
        if (nextBtn) {
            nextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.nextOnboardingStep();
            });
        }
        
        if (prevBtn) {
            prevBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.prevOnboardingStep();
            });
        }
        
        // Language selection - Fixed implementation
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.selectLanguage(e.target.dataset.lang);
            });
        });
        
        // Tab navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.currentTarget.dataset.tab;
                this.switchTab(tab);
            });
        });

        // Voice commands
        const voiceBtn = document.getElementById('voice-btn');
        const cancelVoiceBtn = document.getElementById('cancel-voice');
        
        if (voiceBtn) {
            voiceBtn.addEventListener('click', () => this.toggleVoiceRecognition());
        }
        
        if (cancelVoiceBtn) {
            cancelVoiceBtn.addEventListener('click', () => this.stopVoiceRecognition());
        }

        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }

        // Language switcher
        const languageSwitcher = document.getElementById('language-switcher');
        if (languageSwitcher) {
            languageSwitcher.addEventListener('change', (e) => {
                this.changeLanguage(e.target.value);
            });
        }

        // Form submissions - Fixed implementation
        const profileForm = document.getElementById('profile-form');
        if (profileForm) {
            profileForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveProfileData();
            });
        }

        const periodForm = document.getElementById('period-form');
        if (periodForm) {
            periodForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.savePeriodData();
            });
        }

        const symptomForm = document.getElementById('symptom-form');
        if (symptomForm) {
            symptomForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveSymptomData();
            });
        }

        const medicationForm = document.getElementById('medication-form');
        if (medicationForm) {
            medicationForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addMedication();
            });
        }

        const appointmentForm = document.getElementById('appointment-form');
        if (appointmentForm) {
            appointmentForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.scheduleAppointment();
            });
        }

        // Symptom form tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tabName = e.target.dataset.tab;
                this.switchSymptomTab(tabName);
            });
        });

        // Mood selector
        document.querySelectorAll('.mood-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.selectMood(e.target.dataset.mood));
        });

        // Chart tabs
        document.querySelectorAll('.chart-tab').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchChart(e.target.dataset.chart));
        });

        // Modal close on backdrop click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal.id);
                }
            });
        });

        // Range sliders
        this.setupRangeSliders();

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
        
        // Set default dates
        setTimeout(() => this.setDefaultDates(), 100);
    }

    setupRangeSliders() {
        const sliders = [
            { id: 'pain-level', valueId: 'pain-value' },
            { id: 'sleep-quality', valueId: 'sleep-value' },
            { id: 'energy-level', valueId: 'energy-value' }
        ];
        
        sliders.forEach(slider => {
            const input = document.getElementById(slider.id);
            const output = document.getElementById(slider.valueId);
            
            if (input && output) {
                output.textContent = input.value;
                input.addEventListener('input', function() {
                    output.textContent = this.value;
                });
            }
        });
    }

    // ===========================================
    // ONBOARDING SYSTEM - Fixed Implementation
    // ===========================================

    startOnboarding() {
        const onboardingEl = document.getElementById('onboarding');
        const mainAppEl = document.getElementById('main-app');
        
        if (onboardingEl) onboardingEl.classList.remove('hidden');
        if (mainAppEl) mainAppEl.classList.add('hidden');
        
        this.updateOnboardingUI();
    }

    nextOnboardingStep() {
        if (this.currentStep < this.maxSteps) {
            if (this.validateCurrentStep()) {
                this.currentStep++;
                this.updateOnboardingUI();
            }
        } else {
            this.completeOnboarding();
        }
    }

    prevOnboardingStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.updateOnboardingUI();
        }
    }

    validateCurrentStep() {
        switch (this.currentStep) {
            case 1:
                return true; // Language selection is always valid
            case 2:
                const age = document.getElementById('age');
                const avgCycle = document.getElementById('avg-cycle');
                const lastPeriod = document.getElementById('last-period');
                
                if (!age || !age.value || age.value < 12 || age.value > 65) {
                    this.showNotification('Please enter a valid age (12-65)', 'error');
                    return false;
                }
                
                if (!avgCycle || !avgCycle.value || avgCycle.value < 21 || avgCycle.value > 40) {
                    this.showNotification('Please enter a valid cycle length (21-40 days)', 'error');
                    return false;
                }
                
                if (!lastPeriod || !lastPeriod.value) {
                    this.showNotification('Please select your last period start date', 'error');
                    return false;
                }
                
                return true;
            case 3:
                return true; // Privacy settings are optional
            default:
                return true;
        }
    }

    updateOnboardingUI() {
        // Update step indicators
        document.querySelectorAll('.step-dot').forEach((dot, index) => {
            dot.classList.toggle('active', index < this.currentStep);
        });

        // Update step content
        document.querySelectorAll('.onboarding-step').forEach((step, index) => {
            step.classList.toggle('active', index === this.currentStep - 1);
        });

        // Update navigation buttons
        const prevBtn = document.getElementById('prev-btn');
        const nextBtn = document.getElementById('next-btn');
        
        if (prevBtn) {
            prevBtn.disabled = this.currentStep === 1;
        }
        
        if (nextBtn) {
            nextBtn.textContent = this.currentStep === this.maxSteps ? 
                this.translate('get_started') : this.translate('next');
        }

        // Apply translations
        this.applyTranslations();
    }

    async completeOnboarding() {
        this.showLoading();
        
        // Save onboarding data if on final step
        if (this.currentStep === this.maxSteps) {
            const ageEl = document.getElementById('age');
            const avgCycleEl = document.getElementById('avg-cycle');
            const lastPeriodEl = document.getElementById('last-period');
            const enableVoiceEl = document.getElementById('enable-voice');
            
            this.userData.profile = {
                age: ageEl ? parseInt(ageEl.value) : 25,
                avgCycleLength: avgCycleEl ? parseInt(avgCycleEl.value) : 28,
                lastPeriodDate: lastPeriodEl ? lastPeriodEl.value : this.formatDateISO(new Date()),
                voiceEnabled: enableVoiceEl ? enableVoiceEl.checked : true
            };
        }
        
        this.userData.onboardingComplete = true;
        this.saveUserData();
        
        setTimeout(() => {
            this.hideLoading();
            
            const onboardingEl = document.getElementById('onboarding');
            const mainAppEl = document.getElementById('main-app');
            
            if (onboardingEl) onboardingEl.classList.add('hidden');
            if (mainAppEl) mainAppEl.classList.remove('hidden');
            
            this.isOnboarding = false;
            this.initializeMainApp();
        }, 1000);
    }

    async initializeMainApp() {
        // Initialize dashboard
        this.updateDashboard();
        this.generateMiniCalendar();
        this.updateRecentEntries();
        this.updateInsights();
        this.initializeChart();
        this.loadMedications();
        this.loadAppointments();
        this.applyTranslations();
        this.setDefaultDates();
        
        this.showSuccess(this.translate('welcome_back'));
    }

    // ===========================================
    // LANGUAGE MANAGEMENT
    // ===========================================

    selectLanguage(langCode) {
        if (!langCode) return;
        
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const selectedBtn = document.querySelector(`[data-lang="${langCode}"]`);
        if (selectedBtn) {
            selectedBtn.classList.add('active');
        }
        
        this.changeLanguage(langCode);
    }

    changeLanguage(langCode) {
        if (this.translations[langCode]) {
            this.currentLanguage = langCode;
            this.setStorageItem('preferred_language', langCode);
            this.applyTranslations();
            
            // Update voice recognition language
            if (this.voiceRecognition) {
                this.voiceRecognition.lang = this.getLanguageCode(langCode);
            }
            
            // Update language switcher
            const switcher = document.getElementById('language-switcher');
            if (switcher) {
                switcher.value = langCode;
            }
        }
    }

    translate(key) {
        return this.translations[this.currentLanguage]?.[key] || key;
    }

    applyTranslations() {
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const translation = this.translate(key);
            if (element.tagName === 'INPUT' && (element.type === 'submit' || element.type === 'button')) {
                element.value = translation;
            } else if (element.tagName === 'BUTTON') {
                element.textContent = translation;
            } else {
                element.textContent = translation;
            }
        });

        // Apply RTL for Arabic
        if (this.currentLanguage === 'ar') {
            document.dir = 'rtl';
            document.body.classList.add('rtl');
        } else {
            document.dir = 'ltr';
            document.body.classList.remove('rtl');
        }
    }

    getLanguageCode(lang) {
        const langCodes = {
            en: 'en-US',
            es: 'es-ES',
            fr: 'fr-FR',
            de: 'de-DE',
            hi: 'hi-IN',
            zh: 'zh-CN',
            ar: 'ar-SA',
            pt: 'pt-BR',
            ru: 'ru-RU',
            ja: 'ja-JP'
        };
        return langCodes[lang] || 'en-US';
    }

    // ===========================================
    // VOICE COMMAND SYSTEM
    // ===========================================

    toggleVoiceRecognition() {
        if (!this.userData.settings?.voiceEnabled) {
            this.showNotification('Voice commands are disabled in settings', 'warning');
            return;
        }

        if (this.isListening) {
            this.stopVoiceRecognition();
        } else {
            this.startVoiceRecognition();
        }
    }

    startVoiceRecognition() {
        if (!this.voiceRecognition) {
            this.showNotification('Voice recognition not supported', 'error');
            return;
        }

        try {
            this.isListening = true;
            const overlay = document.getElementById('voice-overlay');
            const btn = document.getElementById('voice-btn');
            const transcript = document.getElementById('voice-transcript');
            
            if (overlay) overlay.classList.remove('hidden');
            if (btn) btn.classList.add('listening');
            if (transcript) transcript.textContent = this.translate('speak_now');
            
            this.voiceRecognition.start();
        } catch (error) {
            console.error('Voice recognition start failed:', error);
            this.stopVoiceRecognition();
        }
    }

    stopVoiceRecognition() {
        if (this.voiceRecognition && this.isListening) {
            this.voiceRecognition.stop();
        }
        
        this.isListening = false;
        const overlay = document.getElementById('voice-overlay');
        const btn = document.getElementById('voice-btn');
        
        if (overlay) overlay.classList.add('hidden');
        if (btn) btn.classList.remove('listening');
    }

    processVoiceCommand(transcript) {
        const command = transcript.toLowerCase().trim();
        console.log('Voice command:', command);
        
        if (command.includes('start period') || command.includes('period started')) {
            this.voiceStartPeriod();
        } else if (command.includes('log symptoms') || command.includes('add symptoms')) {
            this.openModal('symptom-modal');
            this.speak('Symptom logging opened');
        } else if (command.includes('next period') || command.includes('when is my next period')) {
            this.voiceGetNextPeriod();
        } else if (command.includes('go to insights') || command.includes('open insights')) {
            this.switchTab('insights');
            this.speak('Opening insights');
        } else if (command.includes('help')) {
            this.speak('Available commands: Start period, Log symptoms, Next period, Go to insights');
        } else {
            this.speak('Sorry, I didn\'t understand that command.');
        }
        
        this.stopVoiceRecognition();
    }

    voiceStartPeriod() {
        const today = this.formatDateISO(new Date());
        const startInput = document.getElementById('period-start');
        if (startInput) {
            startInput.value = today;
        }
        this.openModal('period-modal');
        this.speak('Period logging opened for today');
    }

    voiceGetNextPeriod() {
        const nextPeriod = this.predictNextPeriod();
        const dateStr = this.formatDate(nextPeriod);
        this.speak(`Your next period is predicted for ${dateStr}`);
    }

    speak(text) {
        if (this.voiceSynthesis && this.userData.settings?.voiceEnabled) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = this.getLanguageCode(this.currentLanguage);
            utterance.rate = 0.9;
            utterance.pitch = 1;
            this.voiceSynthesis.speak(utterance);
        }
    }

    // ===========================================
    // DATA MANAGEMENT
    // ===========================================

    getStorageItem(key) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : null;
        } catch (error) {
            console.error('Storage get error:', error);
            return null;
        }
    }

    setStorageItem(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.error('Storage set error:', error);
        }
    }

    saveUserData() {
        this.setStorageItem('user_data', this.userData);
    }

    saveHealthData() {
        this.healthData.lastBackup = new Date().toISOString();
        this.setStorageItem('health_data', this.healthData);
    }

    // ===========================================
    // CORE TRACKING FUNCTIONS
    // ===========================================

    saveProfileData() {
        const ageEl = document.getElementById('age');
        const avgCycleEl = document.getElementById('avg-cycle');
        const lastPeriodEl = document.getElementById('last-period');
        
        if (!this.validateCurrentStep()) {
            return;
        }
        
        const profile = {
            age: ageEl ? parseInt(ageEl.value) : 25,
            avgCycleLength: avgCycleEl ? parseInt(avgCycleEl.value) : 28,
            lastPeriodDate: lastPeriodEl ? lastPeriodEl.value : this.formatDateISO(new Date())
        };
        
        this.userData.profile = { ...this.userData.profile, ...profile };
        this.saveUserData();
        this.nextOnboardingStep();
    }

    async savePeriodData() {
        this.showLoading();
        
        try {
            const startDateEl = document.getElementById('period-start');
            const endDateEl = document.getElementById('period-end');
            const flowEl = document.querySelector('input[name="flow"]:checked');
            const notesEl = document.getElementById('period-notes');

            const startDate = startDateEl ? startDateEl.value : this.formatDateISO(new Date());
            const endDate = endDateEl ? endDateEl.value : null;
            const flowIntensity = flowEl ? flowEl.value : 'medium';
            const notes = notesEl ? notesEl.value : '';

            const newCycle = {
                id: Date.now(),
                startDate: startDate,
                endDate: endDate,
                flow: [flowIntensity],
                cycleLength: this.calculateCycleLength(startDate),
                notes: notes,
                createdAt: new Date().toISOString()
            };

            this.healthData.cycles.push(newCycle);
            this.saveHealthData();
            
            setTimeout(() => {
                this.hideLoading();
                this.closeModal('period-modal');
                this.showSuccess('Period logged successfully!');
                this.updateDashboard();
                this.updateRecentEntries();
                
                const form = document.getElementById('period-form');
                if (form) form.reset();
            }, 1000);
        } catch (error) {
            this.hideLoading();
            this.showNotification('Failed to save period data', 'error');
        }
    }

    async saveSymptomData() {
        this.showLoading();
        
        try {
            const dateEl = document.getElementById('symptom-date');
            const timeEl = document.getElementById('symptom-time');
            const painEl = document.getElementById('pain-level');
            const moodEl = document.getElementById('selected-mood');
            const sleepEl = document.getElementById('sleep-quality');
            const energyEl = document.getElementById('energy-level');
            const waterEl = document.getElementById('water-intake');
            const exerciseEl = document.getElementById('exercise-minutes');
            const notesEl = document.getElementById('symptom-notes');
            
            const date = dateEl ? dateEl.value : this.formatDateISO(new Date());
            const time = timeEl ? timeEl.value : new Date().toTimeString().slice(0, 5);
            const pain = painEl ? parseInt(painEl.value) : 0;
            const mood = moodEl ? moodEl.value : 'neutral';
            const sleep = sleepEl ? parseInt(sleepEl.value) : 7;
            const energy = energyEl ? parseInt(energyEl.value) : 5;
            const waterIntake = waterEl ? parseInt(waterEl.value) : 8;
            const exerciseMinutes = exerciseEl ? parseInt(exerciseEl.value) : 0;
            const notes = notesEl ? notesEl.value : '';
            
            // Collect symptoms from checkboxes
            const physicalSymptoms = Array.from(document.querySelectorAll('.symptoms-tab[data-tab="physical"] input[type="checkbox"]:checked'))
                                          .map(cb => cb.value);
            
            const emotionalSymptoms = Array.from(document.querySelectorAll('.symptoms-tab[data-tab="emotional"] input[type="checkbox"]:checked'))
                                           .map(cb => cb.value);
            
            const lifestyleSymptoms = Array.from(document.querySelectorAll('.symptoms-tab[data-tab="lifestyle"] input[type="checkbox"]:checked'))
                                            .map(cb => cb.value);

            const newSymptom = {
                id: Date.now(),
                date: date,
                time: time,
                pain: pain,
                mood: mood,
                physicalSymptoms: physicalSymptoms,
                emotionalSymptoms: emotionalSymptoms,
                lifestyleSymptoms: lifestyleSymptoms,
                sleep: sleep,
                energy: energy,
                waterIntake: waterIntake,
                exerciseMinutes: exerciseMinutes,
                notes: notes,
                createdAt: new Date().toISOString()
            };

            this.healthData.symptoms.push(newSymptom);
            this.saveHealthData();
            
            setTimeout(() => {
                this.hideLoading();
                this.closeModal('symptom-modal');
                this.showSuccess('Symptoms logged successfully!');
                this.updateRecentEntries();
                this.updateInsights();
                
                const form = document.getElementById('symptom-form');
                if (form) form.reset();
                this.setupRangeSliders();
            }, 1000);
        } catch (error) {
            this.hideLoading();
            this.showNotification('Failed to save symptom data', 'error');
        }
    }

    async addMedication() {
        const nameEl = document.getElementById('med-name');
        const dosageEl = document.getElementById('med-dosage');
        const frequencyEl = document.getElementById('med-frequency');
        
        const name = nameEl ? nameEl.value : '';
        const dosage = dosageEl ? dosageEl.value : '';
        const frequency = frequencyEl ? frequencyEl.value : 'as-needed';
        
        if (!name) {
            this.showNotification('Please enter medication name', 'error');
            return;
        }
        
        const medication = {
            id: Date.now(),
            name: name,
            dosage: dosage,
            frequency: frequency,
            active: true,
            createdAt: new Date().toISOString()
        };
        
        this.healthData.medications.push(medication);
        this.saveHealthData();
        
        this.loadMedications();
        const form = document.getElementById('medication-form');
        if (form) form.reset();
        this.showSuccess('Medication added successfully');
    }

    async scheduleAppointment() {
        const doctorEl = document.getElementById('appointment-doctor');
        const dateEl = document.getElementById('appointment-date');
        const timeEl = document.getElementById('appointment-time');
        const typeEl = document.getElementById('appointment-type');
        const notesEl = document.getElementById('appointment-notes');
        
        const doctor = doctorEl ? doctorEl.value : '';
        const date = dateEl ? dateEl.value : '';
        const time = timeEl ? timeEl.value : '';
        const type = typeEl ? typeEl.value : 'consultation';
        const notes = notesEl ? notesEl.value : '';
        
        if (!doctor || !date || !time) {
            this.showNotification('Please fill in all required fields', 'error');
            return;
        }
        
        const appointment = {
            id: Date.now(),
            doctor: doctor,
            date: date,
            time: time,
            type: type,
            notes: notes,
            status: 'scheduled',
            createdAt: new Date().toISOString()
        };
        
        this.healthData.appointments.push(appointment);
        this.saveHealthData();
        
        this.loadAppointments();
        const form = document.getElementById('appointment-form');
        if (form) form.reset();
        this.showSuccess('Appointment scheduled successfully');
    }

    // ===========================================
    // DASHBOARD AND UI UPDATES
    // ===========================================

    updateDashboard() {
        // Update cycle day
        const cycleDay = this.getCurrentCycleDay();
        const cycleDayEl = document.getElementById('cycle-day');
        if (cycleDayEl) cycleDayEl.textContent = cycleDay;

        // Update next period prediction
        const nextPeriod = this.predictNextPeriod();
        const nextPeriodEl = document.getElementById('next-period-date');
        if (nextPeriodEl) nextPeriodEl.textContent = this.formatDate(nextPeriod);

        // Update health score
        const healthScore = this.calculateHealthScore();
        const healthScoreEl = document.getElementById('health-score');
        if (healthScoreEl) healthScoreEl.textContent = healthScore;

        // Update predictions
        this.updatePredictions();
        
        this.generateMiniCalendar();
    }

    updatePredictions() {
        const nextPeriod = this.predictNextPeriod();
        const avgCycleLength = this.getAverageCycleLength();
        const ovulationDate = this.predictOvulation();
        const fertileWindow = this.getFertileWindow();
        
        const nextPeriodEl = document.getElementById('prediction-next-period');
        const cycleLengthEl = document.getElementById('prediction-cycle-length');
        const ovulationEl = document.getElementById('prediction-ovulation');
        const fertileEl = document.getElementById('prediction-fertile');
        
        if (nextPeriodEl) nextPeriodEl.textContent = this.formatDate(nextPeriod);
        if (cycleLengthEl) cycleLengthEl.textContent = `${avgCycleLength} days`;
        if (ovulationEl) ovulationEl.textContent = this.formatDate(ovulationDate);
        if (fertileEl) fertileEl.textContent = `${this.formatDate(fertileWindow.start)}-${fertileWindow.end.getDate()}`;
    }

    updateRecentEntries() {
        const container = document.getElementById('recent-entries-list');
        if (!container) return;
        
        const recentSymptoms = this.healthData.symptoms.slice(-3).reverse();
        const recentPeriods = this.healthData.cycles.slice(-2).reverse();
        
        let html = '';
        
        // Add recent symptoms
        recentSymptoms.forEach(symptom => {
            const date = new Date(symptom.date);
            html += `
                <div class="entry-item">
                    <span class="entry-date">${this.formatDate(date)}</span>
                    <span class="entry-type">Symptoms</span>
                    <span class="status status--${symptom.pain > 7 ? 'error' : 'warning'}">Pain: ${symptom.pain}/10</span>
                </div>
            `;
        });
        
        // Add recent periods
        recentPeriods.forEach(period => {
            const date = new Date(period.startDate);
            html += `
                <div class="entry-item">
                    <span class="entry-date">${this.formatDate(date)}</span>
                    <span class="entry-type">Period</span>
                    <span class="status status--info">${period.endDate ? 'Complete' : 'Start Date'}</span>
                </div>
            `;
        });
        
        container.innerHTML = html || '<p>No recent entries</p>';
    }

    updateInsights() {
        const container = document.getElementById('ai-insights-list');
        if (!container) return;
        
        const insights = this.generateInsights();
        
        let html = '';
        insights.forEach(insight => {
            html += `
                <div class="ai-insight">
                    <div class="ai-insight-icon">${insight.icon}</div>
                    <div class="ai-insight-content">
                        <h4>${insight.title}</h4>
                        <p>${insight.content}</p>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }

    generateInsights() {
        const insights = [];
        const avgCycleLength = this.getAverageCycleLength();
        const recentPain = this.healthData.symptoms.slice(-3).map(s => s.pain);
        const avgPain = recentPain.length > 0 ? recentPain.reduce((a, b) => a + b) / recentPain.length : 0;
        
        // Cycle regularity insight
        if (Math.abs(avgCycleLength - 28) > 7) {
            insights.push({
                icon: '⚠️',
                title: 'Cycle Irregularity',
                content: 'Your cycle shows some irregularity. Consider tracking more symptoms to identify patterns.'
            });
        }
        
        // Pain level insight
        if (avgPain > 7) {
            insights.push({
                icon: '🏥',
                title: 'High Pain Levels',
                content: 'Your recent pain levels are elevated. Consider consulting a healthcare provider if this persists.'
            });
        }
        
        // Sleep and energy correlation
        const recentSleep = this.healthData.symptoms.slice(-3).map(s => s.sleep);
        const recentEnergy = this.healthData.symptoms.slice(-3).map(s => s.energy);
        if (recentSleep.length > 0 && recentEnergy.length > 0) {
            const avgSleep = recentSleep.reduce((a, b) => a + b) / recentSleep.length;
            const avgEnergy = recentEnergy.reduce((a, b) => a + b) / recentEnergy.length;
            
            if (avgSleep < 6 && avgEnergy < 5) {
                insights.push({
                    icon: '😴',
                    title: 'Sleep & Energy',
                    content: 'Your sleep quality appears to affect your energy levels. Try improving sleep hygiene.'
                });
            }
        }
        
        // Positive insight
        if (insights.length === 0) {
            insights.push({
                icon: '✨',
                title: 'Great Progress!',
                content: 'Great job tracking your health! Your data shows healthy patterns.'
            });
        }
        
        return insights;
    }

    // Calendar generation
    generateMiniCalendar() {
        const calendar = document.getElementById('mini-calendar');
        if (!calendar) return;
        
        const today = new Date();
        const year = today.getFullYear();
        const month = today.getMonth();
        
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startDay = firstDay.getDay();
        
        calendar.innerHTML = '';
        
        // Add day headers
        const dayHeaders = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
        dayHeaders.forEach(day => {
            const dayEl = document.createElement('div');
            dayEl.textContent = day;
            dayEl.className = 'calendar-header';
            dayEl.style.fontWeight = 'bold';
            dayEl.style.color = 'var(--color-text-secondary)';
            calendar.appendChild(dayEl);
        });
        
        // Add empty cells
        for (let i = 0; i < startDay; i++) {
            const emptyDay = document.createElement('div');
            calendar.appendChild(emptyDay);
        }
        
        // Add days
        for (let day = 1; day <= daysInMonth; day++) {
            const dayEl = document.createElement('div');
            dayEl.textContent = day;
            dayEl.className = 'calendar-day';
            
            const currentDate = new Date(year, month, day);
            const dateStr = this.formatDateISO(currentDate);
            
            if (day === today.getDate()) {
                dayEl.classList.add('today');
            }
            
            if (this.isPeriodDay(dateStr)) {
                dayEl.classList.add('period');
            }
            
            calendar.appendChild(dayEl);
        }
    }

    isPeriodDay(dateStr) {
        return this.healthData.cycles.some(cycle => {
            if (!cycle.endDate) return dateStr === cycle.startDate;
            
            const start = new Date(cycle.startDate);
            const end = new Date(cycle.endDate);
            const check = new Date(dateStr);
            
            return check >= start && check <= end;
        });
    }

    loadMedications() {
        const container = document.getElementById('medication-list');
        if (!container) return;
        
        let html = '';
        this.healthData.medications.forEach(med => {
            if (med.active) {
                html += `
                    <div class="medication-item">
                        <div class="medication-info">
                            <div class="medication-name">${med.name}</div>
                            <div class="medication-details">${med.dosage} - ${med.frequency}</div>
                        </div>
                        <div class="item-actions">
                            <button class="item-action delete" onclick="window.herAI.removeMedication(${med.id})">Remove</button>
                        </div>
                    </div>
                `;
            }
        });
        
        container.innerHTML = html || '<p>No medications added yet.</p>';
    }

    loadAppointments() {
        const container = document.getElementById('appointment-list');
        if (!container) return;
        
        let html = '';
        this.healthData.appointments.forEach(apt => {
            if (apt.status === 'scheduled') {
                html += `
                    <div class="appointment-item">
                        <div class="appointment-info">
                            <div class="appointment-doctor">${apt.doctor}</div>
                            <div class="appointment-details">${apt.date} at ${apt.time} - ${apt.type}</div>
                        </div>
                        <div class="item-actions">
                            <button class="item-action delete" onclick="window.herAI.cancelAppointment(${apt.id})">Cancel</button>
                        </div>
                    </div>
                `;
            }
        });
        
        container.innerHTML = html || '<p>No appointments scheduled.</p>';
    }

    // ===========================================
    // UTILITY FUNCTIONS
    // ===========================================

    calculateHealthScore() {
        let score = 100;
        const recentSymptoms = this.healthData.symptoms.slice(-30);
        
        if (recentSymptoms.length === 0) return 85;
        
        const avgPain = recentSymptoms.reduce((sum, s) => sum + s.pain, 0) / recentSymptoms.length;
        score -= avgPain * 3;
        
        const avgSleep = recentSymptoms.reduce((sum, s) => sum + s.sleep, 0) / recentSymptoms.length;
        if (avgSleep < 6) score -= 10;
        
        const avgEnergy = recentSymptoms.reduce((sum, s) => sum + s.energy, 0) / recentSymptoms.length;
        if (avgEnergy < 5) score -= 8;
        
        return Math.max(Math.round(score), 0);
    }

    getCurrentCycleDay() {
        const lastCycle = this.getLastCycle();
        if (!lastCycle) return 1;
        
        const startDate = new Date(lastCycle.startDate);
        const today = new Date();
        const diffTime = today - startDate;
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        return Math.max(1, diffDays + 1);
    }

    predictNextPeriod() {
        const avgCycleLength = this.getAverageCycleLength();
        const lastCycle = this.getLastCycle();
        
        if (!lastCycle) {
            const today = new Date();
            today.setDate(today.getDate() + avgCycleLength);
            return today;
        }
        
        const lastStart = new Date(lastCycle.startDate);
        const nextPeriod = new Date(lastStart);
        nextPeriod.setDate(nextPeriod.getDate() + avgCycleLength);
        
        return nextPeriod;
    }

    predictOvulation() {
        const nextPeriod = this.predictNextPeriod();
        const ovulation = new Date(nextPeriod);
        ovulation.setDate(ovulation.getDate() - 14);
        return ovulation;
    }

    getFertileWindow() {
        const ovulation = this.predictOvulation();
        const start = new Date(ovulation);
        start.setDate(start.getDate() - 5);
        const end = new Date(ovulation);
        end.setDate(end.getDate() + 1);
        
        return { start, end };
    }

    getLastCycle() {
        return this.healthData.cycles.sort((a, b) => new Date(b.startDate) - new Date(a.startDate))[0];
    }

    getAverageCycleLength() {
        const cycles = this.healthData.cycles.filter(c => c.cycleLength);
        if (cycles.length === 0) return this.userData.profile?.avgCycleLength || 28;
        
        const total = cycles.reduce((sum, cycle) => sum + cycle.cycleLength, 0);
        return Math.round(total / cycles.length);
    }

    calculateCycleLength(startDate) {
        const lastCycle = this.getLastCycle();
        if (!lastCycle) return 28;
        
        const lastStart = new Date(lastCycle.startDate);
        const currentStart = new Date(startDate);
        const diffTime = currentStart - lastStart;
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        return diffDays > 0 ? diffDays : 28;
    }

    formatDate(date) {
        return date.toLocaleDateString(this.getLanguageCode(this.currentLanguage), { 
            month: 'short', 
            day: 'numeric' 
        });
    }

    formatDateISO(date) {
        return date.toISOString().split('T')[0];
    }

    // ===========================================
    // UI HELPER FUNCTIONS
    // ===========================================

    switchTab(tabName) {
        document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
        const activeBtn = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeBtn) activeBtn.classList.add('active');

        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        const activeContent = document.getElementById(tabName);
        if (activeContent) activeContent.classList.add('active');

        if (tabName === 'insights') {
            setTimeout(() => this.updateChart(), 100);
        }
    }

    switchSymptomTab(tabName) {
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        const activeBtn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
        if (activeBtn) activeBtn.classList.add('active');

        document.querySelectorAll('.symptoms-tab').forEach(tab => tab.classList.remove('active'));
        const activeTab = document.querySelector(`.symptoms-tab[data-tab="${tabName}"]`);
        if (activeTab) activeTab.classList.add('active');
    }

    selectMood(mood) {
        document.querySelectorAll('.mood-btn').forEach(btn => btn.classList.remove('selected'));
        const selectedBtn = document.querySelector(`[data-mood="${mood}"]`);
        if (selectedBtn) selectedBtn.classList.add('selected');
        
        const hiddenInput = document.getElementById('selected-mood');
        if (hiddenInput) hiddenInput.value = mood;
    }

    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        }
    }

    showLoading() {
        const loading = document.getElementById('loading');
        if (loading) loading.classList.remove('hidden');
    }

    hideLoading() {
        const loading = document.getElementById('loading');
        if (loading) loading.classList.add('hidden');
    }

    showSuccess(message) {
        const element = document.getElementById('success-message');
        const textElement = document.getElementById('success-text');
        
        if (textElement) textElement.textContent = message;
        if (element) {
            element.classList.remove('hidden');
            setTimeout(() => element.classList.add('hidden'), 3000);
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type} show`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-icon">${type === 'error' ? '❌' : type === 'warning' ? '⚠️' : type === 'success' ? '✅' : 'ℹ️'}</span>
                <span class="notification-text">${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-color-scheme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-color-scheme', newTheme);
        
        const themeBtn = document.getElementById('theme-toggle');
        if (themeBtn) {
            themeBtn.textContent = newTheme === 'dark' ? '☀️' : '🌙';
        }
        
        this.userData.settings.theme = newTheme;
        this.saveUserData();
    }

    setDefaultDates() {
        const today = this.formatDateISO(new Date());
        const periodStart = document.getElementById('period-start');
        const symptomDate = document.getElementById('symptom-date');
        const lastPeriod = document.getElementById('last-period');
        
        if (periodStart && !periodStart.value) periodStart.value = today;
        if (symptomDate && !symptomDate.value) symptomDate.value = today;
        if (lastPeriod && !lastPeriod.value) {
            // Set to 28 days ago as default
            const lastPeriodDate = new Date();
            lastPeriodDate.setDate(lastPeriodDate.getDate() - 28);
            lastPeriod.value = this.formatDateISO(lastPeriodDate);
        }
    }

    handleKeyboardShortcuts(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal:not(.hidden)').forEach(modal => {
                modal.classList.add('hidden');
            });
            document.body.style.overflow = 'auto';
            this.stopVoiceRecognition();
        }
    }

    // ===========================================
    // CHART MANAGEMENT
    // ===========================================

    initializeChart() {
        const ctx = document.getElementById('main-chart');
        if (!ctx) return;
        
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.getLastSixMonths(),
                datasets: [{
                    label: 'Cycle Length (days)',
                    data: this.getCycleLengthData(),
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 40
                    }
                }
            }
        });
    }

    updateChart() {
        if (!this.chart) {
            this.initializeChart();
            return;
        }
        
        this.chart.data.labels = this.getLastSixMonths();
        this.chart.data.datasets[0].data = this.getCycleLengthData();
        this.chart.update();
    }

    switchChart(chartType) {
        document.querySelectorAll('.chart-tab').forEach(tab => tab.classList.remove('active'));
        const activeTab = document.querySelector(`[data-chart="${chartType}"]`);
        if (activeTab) activeTab.classList.add('active');
        
        if (!this.chart) return;
        
        switch (chartType) {
            case 'cycle':
                this.chart.data.datasets = [{
                    label: 'Cycle Length (days)',
                    data: this.getCycleLengthData(),
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4,
                    fill: true
                }];
                this.chart.options.scales.y.max = 40;
                break;
            case 'pain':
                this.chart.data.datasets = [{
                    label: 'Pain Level (avg)',
                    data: this.getPainLevelData(),
                    borderColor: '#B4413C',
                    backgroundColor: 'rgba(180, 65, 60, 0.1)',
                    tension: 0.4,
                    fill: true
                }];
                this.chart.options.scales.y.max = 10;
                break;
        }
        
        this.chart.update();
    }

    getLastSixMonths() {
        const months = [];
        const today = new Date();
        
        for (let i = 5; i >= 0; i--) {
            const date = new Date(today.getFullYear(), today.getMonth() - i, 1);
            months.push(date.toLocaleDateString('en-US', { month: 'short' }));
        }
        
        return months;
    }

    getCycleLengthData() {
        const months = this.getLastSixMonths();
        return months.map(() => {
            return this.getAverageCycleLength() + (Math.random() - 0.5) * 4;
        });
    }

    getPainLevelData() {
        const months = this.getLastSixMonths();
        return months.map(() => {
            return Math.floor(Math.random() * 5) + 3;
        });
    }

    // ===========================================
    // PLACEHOLDER FUNCTIONS FOR FEATURES
    // ===========================================

    removeMedication(id) {
        this.healthData.medications = this.healthData.medications.map(med => 
            med.id === id ? { ...med, active: false } : med
        );
        this.saveHealthData();
        this.loadMedications();
        this.showSuccess('Medication removed');
    }

    cancelAppointment(id) {
        this.healthData.appointments = this.healthData.appointments.map(apt => 
            apt.id === id ? { ...apt, status: 'cancelled' } : apt
        );
        this.saveHealthData();
        this.loadAppointments();
        this.showSuccess('Appointment cancelled');
    }
}

// ===========================================
// GLOBAL FUNCTIONS FOR HTML
// ===========================================

function openModal(modalId) {
    if (window.herAI) window.herAI.openModal(modalId);
}

function closeModal(modalId) {
    if (window.herAI) window.herAI.closeModal(modalId);
}

function generateReport() {
    if (window.herAI) {
        window.herAI.showNotification('Report generation feature coming soon!', 'info');
    }
}

function exportData() {
    if (window.herAI) {
        const dataStr = JSON.stringify(window.herAI.healthData, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `her-ai-data-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        window.herAI.showSuccess('Data exported successfully!');
    }
}

function shareReport() {
    if (window.herAI) {
        window.herAI.showNotification('Share feature coming soon!', 'info');
    }
}

function showEducationContent(topic) {
    if (window.herAI) {
        window.herAI.showNotification('Educational content feature coming soon!', 'info');
    }
}

function backupData() {
    if (window.herAI) {
        window.herAI.showNotification('Data backup feature coming soon!', 'info');
    }
}

function restoreData() {
    if (window.herAI) {
        window.herAI.showNotification('Data restore feature coming soon!', 'info');
    }
}

function secureDelete() {
    if (window.herAI && confirm('Are you sure you want to delete all data? This cannot be undone.')) {
        localStorage.clear();
        window.location.reload();
    }
}

function addEmergencyContact() {
    if (window.herAI) {
        window.herAI.showNotification('Emergency contacts feature coming soon!', 'info');
    }
}

// ===========================================
// APP INITIALIZATION
// ===========================================

document.addEventListener('DOMContentLoaded', function() {
    window.herAI = new HerAI();
});

document.addEventListener('visibilitychange', function() {
    if (document.hidden && window.herAI && window.herAI.isListening) {
        window.herAI.stopVoiceRecognition();
    }
});

window.addEventListener('beforeunload', function() {
    if (window.herAI) {
        window.herAI.saveUserData();
        window.herAI.saveHealthData();
    }
});